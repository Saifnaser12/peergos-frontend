import DocumentManagement from '@/components/documents/document-management';

export default function Documents() {
  return <DocumentManagement />;
}