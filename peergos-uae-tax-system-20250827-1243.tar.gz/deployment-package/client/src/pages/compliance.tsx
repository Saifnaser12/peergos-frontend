import ComplianceMonitoringDashboard from '@/components/compliance/compliance-monitoring-dashboard';

export default function Compliance() {
  return <ComplianceMonitoringDashboard />;
}