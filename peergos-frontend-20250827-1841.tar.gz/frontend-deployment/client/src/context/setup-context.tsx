import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { BusinessInfo, RevenueDeclaration, FreeZoneLicense, TRNUpload, SummaryReview, CompleteSetup } from '@/lib/setup-validation';

interface SetupContextType {
  currentStep: number;
  businessInfo: Partial<BusinessInfo>;
  revenueDeclaration: Partial<RevenueDeclaration>;
  freeZoneLicense: Partial<FreeZoneLicense>;
  trnUpload: Partial<TRNUpload>;
  summaryReview: Partial<SummaryReview>;
  
  // Navigation
  setCurrentStep: (step: number) => void;
  nextStep: () => void;
  prevStep: () => void;
  
  // Data updates
  updateBusinessInfo: (data: Partial<BusinessInfo>) => void;
  updateRevenueDeclaration: (data: Partial<RevenueDeclaration>) => void;
  updateFreeZoneLicense: (data: Partial<FreeZoneLicense>) => void;
  updateTRNUpload: (data: Partial<TRNUpload>) => void;
  updateSummaryReview: (data: Partial<SummaryReview>) => void;
  
  // Utility
  resetSetup: () => void;
  getCompleteSetup: () => CompleteSetup | null;
  saveProgress: () => void;
  loadProgress: () => void;
  
  // Validation state
  stepValidation: Record<number, boolean>;
  updateStepValidation: (step: number, isValid: boolean) => void;
}

const SetupContext = createContext<SetupContextType | undefined>(undefined);

const STORAGE_KEY = 'peergos_setup_progress';
const VALIDATION_KEY = 'peergos_setup_validation';

export function SetupProvider({ children }: { children: ReactNode }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [businessInfo, setBusinessInfo] = useState<Partial<BusinessInfo>>({});
  const [revenueDeclaration, setRevenueDeclaration] = useState<Partial<RevenueDeclaration>>({
    hasInternationalSales: false,
  });
  const [freeZoneLicense, setFreeZoneLicense] = useState<Partial<FreeZoneLicense>>({
    licenseType: 'Mainland',
    freeZoneName: '',
    licenseNumber: '',
    licenseIssueDate: '',
    licenseExpiryDate: '',
    isQFZP: false,
    docs: [],
  });
  const [trnUpload, setTRNUpload] = useState<Partial<TRNUpload>>({
    hasTRN: false,
    citRegistrationRequired: true,
    taxAgentAppointed: false,
  });
  const [summaryReview, setSummaryReview] = useState<Partial<SummaryReview>>({
    confirmFinancialYearEnd: '',
    wantsSmartReminders: true,
    agreeToTerms: false,
    readyToStart: false,
  });
  const [stepValidation, setStepValidation] = useState<Record<number, boolean>>({
    1: false,
    2: false,
    3: false,
    4: false,
    5: false,
  });

  // Auto-save progress to localStorage
  useEffect(() => {
    saveProgress();
  }, [businessInfo, revenueDeclaration, freeZoneLicense, trnUpload, summaryReview, currentStep]);

  const updateBusinessInfo = (data: Partial<BusinessInfo>) => {
    setBusinessInfo(prev => ({ ...prev, ...data }));
  };

  const updateRevenueDeclaration = (data: Partial<RevenueDeclaration>) => {
    setRevenueDeclaration(prev => ({ ...prev, ...data }));
  };

  const updateFreeZoneLicense = (data: Partial<FreeZoneLicense>) => {
    setFreeZoneLicense(prev => ({ ...prev, ...data }));
  };

  const updateTRNUpload = (data: Partial<TRNUpload>) => {
    setTRNUpload(prev => ({ ...prev, ...data }));
  };

  const updateSummaryReview = (data: Partial<SummaryReview>) => {
    setSummaryReview(prev => ({ ...prev, ...data }));
  };

  const updateStepValidation = (step: number, isValid: boolean) => {
    setStepValidation(prev => ({ ...prev, [step]: isValid }));
    // Save validation state to localStorage
    localStorage.setItem(VALIDATION_KEY, JSON.stringify({ ...stepValidation, [step]: isValid }));
  };

  const nextStep = () => {
    if (currentStep < 5 && stepValidation[currentStep]) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const resetSetup = () => {
    setCurrentStep(1);
    setBusinessInfo({});
    setRevenueDeclaration({ hasInternationalSales: false });
    setFreeZoneLicense({ licenseType: 'Mainland', freeZoneName: '', licenseNumber: '', licenseIssueDate: '', licenseExpiryDate: '', isQFZP: false, docs: [] });
    setTRNUpload({ hasTRN: false, citRegistrationRequired: true, taxAgentAppointed: false });
    setSummaryReview({ confirmFinancialYearEnd: '', wantsSmartReminders: true, agreeToTerms: false, readyToStart: false });
    setStepValidation({ 1: false, 2: false, 3: false, 4: false, 5: false });
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(VALIDATION_KEY);
  };

  const saveProgress = () => {
    const progressData = {
      currentStep,
      businessInfo,
      revenueDeclaration,
      freeZoneLicense,
      trnUpload,
      summaryReview,
      timestamp: new Date().toISOString(),
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progressData));
  };

  const loadProgress = () => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      const savedValidation = localStorage.getItem(VALIDATION_KEY);
      
      if (saved) {
        const progressData = JSON.parse(saved);
        setCurrentStep(progressData.currentStep || 1);
        setBusinessInfo(progressData.businessInfo || {});
        setRevenueDeclaration(progressData.revenueDeclaration || { hasInternationalSales: false });
        setFreeZoneLicense(progressData.freeZoneLicense || { licenseType: 'Mainland', freeZoneName: '', licenseNumber: '', licenseIssueDate: '', licenseExpiryDate: '', isQFZP: false, docs: [] });
        setTRNUpload(progressData.trnUpload || { hasTRN: false, citRegistrationRequired: true, taxAgentAppointed: false });
        setSummaryReview(progressData.summaryReview || { confirmFinancialYearEnd: '', wantsSmartReminders: true, agreeToTerms: false, readyToStart: false });
      }
      
      if (savedValidation) {
        const validationData = JSON.parse(savedValidation);
        setStepValidation(validationData);
      }
    } catch (error) {
      console.warn('Failed to load setup progress:', error);
    }
  };

  const getCompleteSetup = (): CompleteSetup | null => {
    try {
      return {
        businessInfo: businessInfo as BusinessInfo,
        revenueDeclaration: revenueDeclaration as RevenueDeclaration,
        freeZoneLicense: freeZoneLicense as FreeZoneLicense,
        trnUpload: trnUpload as TRNUpload,
        summaryReview: summaryReview as SummaryReview,
      };
    } catch {
      return null;
    }
  };

  // Load progress on mount
  useEffect(() => {
    loadProgress();
  }, []);

  const value: SetupContextType = {
    currentStep,
    businessInfo,
    revenueDeclaration,
    freeZoneLicense,
    trnUpload,
    summaryReview,
    setCurrentStep,
    nextStep,
    prevStep,
    updateBusinessInfo,
    updateRevenueDeclaration,
    updateFreeZoneLicense,
    updateTRNUpload,
    updateSummaryReview,
    resetSetup,
    getCompleteSetup,
    saveProgress,
    loadProgress,
    stepValidation,
    updateStepValidation,
  };

  return (
    <SetupContext.Provider value={value}>
      {children}
    </SetupContext.Provider>
  );
}

export function useSetup() {
  const context = useContext(SetupContext);
  if (context === undefined) {
    throw new Error('useSetup must be used within a SetupProvider');
  }
  return context;
}