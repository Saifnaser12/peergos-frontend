import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { useLanguage } from '@/context/language-context';
import { useToast } from '@/hooks/use-toast';
import TransferPricingForm from '@/components/tax/transfer-pricing-form';
import TransferPricingCalculator from '@/components/compliance/transfer-pricing-calculator';
import DMTTCalculator from '@/components/compliance/dmtt-calculator';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { 
  ArrowRightLeft, 
  Upload, 
  FileText, 
  AlertCircle, 
  Building2,
  TrendingUp,
  Shield,
  Flag,
  CheckCircle,
  Info,
  Calculator,
  DollarSign,
  Users,
  Download,
  Eye
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatCurrency } from '@/lib/i18n';
import { apiRequest } from '@/lib/queryClient';

interface RelatedPartyTransaction {
  id: number;
  relatedPartyName: string;
  relationship: string;
  transactionType: 'goods' | 'services' | 'financing' | 'ip' | 'other';
  amount: number;
  armLengthPrice: number;
  methodology: string;
  documentation: string;
  riskLevel: 'low' | 'medium' | 'high';
  createdAt: string;
}

interface TransferPricingMethod {
  name: string;
  description: string;
  applicability: string;
  advantages: string[];
  requirements: string[];
}

export default function TransferPricing() {
  const { user, company } = useAuth();
  const { language, t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [activeTab, setActiveTab] = useState('overview');
  const [showAddTransaction, setShowAddTransaction] = useState(false);
  const [newTransaction, setNewTransaction] = useState({
    relatedPartyName: '',
    relationship: '',
    transactionType: 'services' as const,
    amount: 0,
    armLengthPrice: 0,
    methodology: '',
    documentation: ''
  });

  // Transfer pricing data query
  const { data: relatedPartyTransactions = [] } = useQuery({
    queryKey: ['/api/transfer-pricing/transactions'],
    enabled: !!company?.id
  });

  // Transfer pricing analysis
  const totalRelatedPartyTransactions = relatedPartyTransactions.reduce((sum: number, txn: any) => sum + (txn.amount || 0), 0);
  const averageAdjustment = relatedPartyTransactions.length > 0 
    ? relatedPartyTransactions.reduce((sum: number, txn: any) => sum + Math.abs((txn.amount || 0) - (txn.armLengthPrice || 0)), 0) / relatedPartyTransactions.length
    : 0;
  
  // Calculate compliance score based on documentation and arm's length principle
  const baseComplianceScore = relatedPartyTransactions.length > 0
    ? Math.round(relatedPartyTransactions.filter((txn: any) => txn.documentation && Math.abs((txn.amount || 0) - (txn.armLengthPrice || 0)) < (txn.amount || 0) * 0.05).length / relatedPartyTransactions.length * 100)
    : 100;

  // FTA-approved transfer pricing methods
  const transferPricingMethods: TransferPricingMethod[] = [
    {
      name: 'Comparable Uncontrolled Price (CUP)',
      description: 'Compares the price charged in a controlled transaction with the price charged in a comparable uncontrolled transaction',
      applicability: 'Goods and services with comparable market transactions',
      advantages: ['Most direct method', 'Generally reliable', 'Easy to apply when comparables exist'],
      requirements: ['Comparable transactions', 'Similar circumstances', 'Minimal adjustments needed']
    },
    {
      name: 'Resale Price Method (RPM)',
      description: 'Based on the price at which a product purchased from a related enterprise is resold to an independent enterprise',
      applicability: 'Distribution and marketing operations',
      advantages: ['Suitable for distributors', 'Uses internal data', 'Good for routine operations'],
      requirements: ['Gross margin data', 'Functional analysis', 'Comparable gross margins']
    },
    {
      name: 'Cost Plus Method (CPM)',
      description: 'Uses the costs incurred by the supplier of property in a controlled transaction',
      applicability: 'Manufacturing and service providers',
      advantages: ['Good for cost centers', 'Uses internal data', 'Suitable for contract manufacturers'],
      requirements: ['Reliable cost data', 'Appropriate markup', 'Functional comparability']
    },
    {
      name: 'Transactional Net Margin Method (TNMM)',
      description: 'Examines the net profit margin relative to an appropriate base from controlled transactions',
      applicability: 'Complex transactions where traditional methods are difficult to apply',
      advantages: ['Less sensitive to differences', 'Uses net margins', 'Widely accepted'],
      requirements: ['Operating level indicators', 'Multi-year data', 'Economic analysis']
    },
    {
      name: 'Profit Split Method',
      description: 'Identifies the combined profit to be split from controlled transactions and divides it between related enterprises',
      applicability: 'Highly integrated operations with unique intangibles',
      advantages: ['Suitable for unique transactions', 'Considers both parties', 'Good for intangibles'],
      requirements: ['Combined profit calculation', 'Allocation keys', 'Detailed functional analysis']
    }
  ];

  const calculateComplianceScore = () => {
    const totalTransactions = relatedPartyTransactions.length;
    const documentedTransactions = relatedPartyTransactions.filter(t => t.documentation).length;
    const lowRiskTransactions = relatedPartyTransactions.filter(t => t.riskLevel === 'low').length;
    
    if (totalTransactions === 0) return 0;
    
    const documentationScore = (documentedTransactions / totalTransactions) * 50;
    const riskScore = (lowRiskTransactions / totalTransactions) * 50;
    
    return Math.round(documentationScore + riskScore);
  };

  const complianceScore = calculateComplianceScore();

  const addTransaction = () => {
    // In real app, this would call API
    console.log('Adding transaction:', newTransaction);
    setNewTransaction({
      relatedPartyName: '',
      relationship: '',
      transactionType: 'services',
      amount: 0,
      armLengthPrice: 0,
      methodology: '',
      documentation: ''
    });
    setShowAddTransaction(false);
    toast({
      title: 'Success',
      description: 'Related party transaction added successfully',
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-red-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* UAE FTA Header */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="flex items-center gap-2">
              <Flag className="h-6 w-6 text-green-600" />
              <span className="text-lg font-bold bg-gradient-to-r from-green-600 to-red-600 bg-clip-text text-transparent">
                UAE FTA
              </span>
            </div>
            <div className="h-6 w-px bg-gray-300" />
            <div className="flex items-center gap-2">
              <Shield className="h-6 w-6 text-blue-600" />
              <span className="text-lg font-bold text-gray-900">Transfer Pricing</span>
            </div>
          </div>
        </div>

        {/* Header */}
        <div className={cn("flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", language === 'ar' && "rtl:flex-row-reverse")}>
          <div>
            <div className={cn("flex items-center gap-3", language === 'ar' && "rtl:flex-row-reverse")}>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900">SME Transfer Pricing</h1>
              <Badge className="bg-green-100 text-green-800">
                <Shield size={14} className="mr-1" />
                FTA Compliant
              </Badge>
            </div>
            <p className="text-gray-600 mt-1">
              Manage related party transactions and arm's length pricing per UAE FTA requirements
            </p>
          </div>
        </div>

        {/* Compliance Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-700">Compliance Score</p>
                  <p className="text-2xl font-bold text-blue-900">{complianceScore}%</p>
                </div>
                <TrendingUp className="h-8 w-8 text-blue-600" />
              </div>
              <Progress value={complianceScore} className="mt-2 h-2" />
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-green-50 to-green-100 border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-700">Total Transactions</p>
                  <p className="text-2xl font-bold text-green-900">{relatedPartyTransactions.length}</p>
                </div>
                <ArrowRightLeft className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-purple-50 to-purple-100 border-purple-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-700">Total Value</p>
                  <p className="text-xl font-bold text-purple-900">
                    {formatCurrency(
                      relatedPartyTransactions.reduce((sum, t) => sum + t.amount, 0),
                      'AED',
                      'en-AE'
                    )}
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-orange-50 to-orange-100 border-orange-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-orange-700">Documentation</p>
                  <p className="text-2xl font-bold text-orange-900">
                    {relatedPartyTransactions.filter(t => t.documentation).length}/
                    {relatedPartyTransactions.length}
                  </p>
                </div>
                <FileText className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="documentation">Transfer Pricing Form</TabsTrigger>
            <TabsTrigger value="calculator">TP Calculator</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Info className="h-5 w-5 text-blue-600" />
                    FTA Transfer Pricing Requirements
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Small & Medium Businesses</h4>
                        <p className="text-sm text-gray-600">
                          Revenue &lt; AED 150M and employees &lt; 250 FTE
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Related Party Disclosure</h4>
                        <p className="text-sm text-gray-600">
                          Annual disclosure required in CIT return if total transactions exceed AED 1M
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Documentation Requirements</h4>
                        <p className="text-sm text-gray-600">
                          Maintain documentation demonstrating arm's length nature
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Audit Defense</h4>
                        <p className="text-sm text-gray-600">
                          Be ready to provide supporting documents upon FTA request
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calculator className="h-5 w-5 text-purple-600" />
                    Risk Assessment
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                      <span className="font-medium text-green-900">Low Risk Transactions</span>
                      <Badge className="bg-green-100 text-green-800">
                        {relatedPartyTransactions.filter(t => t.riskLevel === 'low').length}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                      <span className="font-medium text-yellow-900">Medium Risk Transactions</span>
                      <Badge className="bg-yellow-100 text-yellow-800">
                        {relatedPartyTransactions.filter(t => t.riskLevel === 'medium').length}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                      <span className="font-medium text-red-900">High Risk Transactions</span>
                      <Badge className="bg-red-100 text-red-800">
                        {relatedPartyTransactions.filter(t => t.riskLevel === 'high').length}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Alert className="border-blue-200 bg-blue-50">
              <Info className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                <strong>SME Simplification:</strong> For small and medium businesses, UAE FTA focuses on substance over form. 
                Maintain proper documentation and ensure transactions reflect commercial rationale and arm's length pricing.
              </AlertDescription>
            </Alert>
          </TabsContent>

          {/* Transfer Pricing Documentation Form */}
          <TabsContent value="documentation" className="space-y-6">
            <TransferPricingForm 
              mode="submit"
              onSubmit={(data) => {
                console.log('Transfer Pricing Form Submitted:', data);
                toast({
                  title: "Documentation Submitted",
                  description: "Your transfer pricing documentation has been submitted successfully.",
                });
              }}
            />
          </TabsContent>

          {/* Transfer Pricing Calculator */}
          <TabsContent value="calculator" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Transfer Pricing Calculator
                </CardTitle>
              </CardHeader>
              <CardContent>
                <TransferPricingCalculator />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}