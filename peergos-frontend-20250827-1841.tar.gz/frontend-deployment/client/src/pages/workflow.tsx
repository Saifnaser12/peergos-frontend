import SMEComplianceWorkflow from '@/components/workflow/sme-compliance-workflow';

export default function Workflow() {
  return <SMEComplianceWorkflow />;
}