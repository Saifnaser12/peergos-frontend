import { useNotifications } from '../context/notification-context';

export { useNotifications };
